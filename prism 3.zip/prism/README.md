# Prism – a match-three game

Next.js + Tailwind CSS. This folder is a complete project, ready to upload to GitHub and deploy on Vercel.

## Run it on your computer (optional)

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Publish it

1. Upload this whole folder to a new GitHub repository.
2. Go to vercel.com, sign in with GitHub, click Add New > Project, import the repo, click Deploy.

## Tweak it

- `lib/game.ts`: `SIZE`, `KINDS`, `MOVES` and `GOAL` control board size, tile variety and difficulty.
- `components/candy-game.tsx`: `PALETTE` holds the gem colours.
